<html>
    <head>
        <title>The Lodge | Process Update Details</title>
        <?php
        include "head.inc.php"
        ?>
    </head>
    <body>
        <?php
        include "nav.inc.php";
        ?>
        <header class="jumbotron jumbotron-fluid text-center">
            <h1 class="display-4">Update Details</h1>
        </header>
        <main class ="container">
            <?php
            $fname = $lname = $email = $pwd_hashed = $country = $errorMsg = "";
            $success = true;
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                
                $memberid = (int)$_SESSION["memberid"];
                
                if (!empty($_POST["fname"])) {
                    $fname = sanitize_input($_POST["fname"]);
                }

                if (empty($_POST["lname"])) {
                    $errorMsg .= "Last name is required.<br>";
                    $success = false;
                } else {
                    $lname = sanitize_input($_POST["lname"]);
                }
                if (empty($_POST["country"])) {
                    $errorMsg .= "Country is required.<br>";
                    $success = false;
                } else {
                    $country = sanitize_input($_POST["country"]);
                }
                if (empty($_POST["email"])) {
                    $errorMsg .= "Email is required.<br>";
                    $success = false;
                } else {
                    $email = sanitize_input($_POST["email"]);
                    // Additional check to make sure e-mail address is well-formed.
                    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $errorMsg .= "Invalid email format.<br>";
                        $success = false;
                    }
                }

                //Checks if current password is filled in, if it is check if either new password or confirm new password is empty
                if (!empty($_POST["oldpwd"]) && ( (!empty($_POST["pwd"]) && empty($_POST["pwd_confirm"])) || (empty($_POST["pwd"]) && !empty($_POST["pwd_confirm"])) ) ) {
                    $errorMsg .= "Password fields are required to change password.<br>";
                    $success = false;
                } else {
                    if ($_POST["pwd"] != $_POST["pwd_confirm"]) {
                        $errorMsg .= "Passwords do not match.<br>";
                        $success = false;
                    } else {
                        $pwd_hashed = password_hash($_POST["pwd"], PASSWORD_DEFAULT);
                    }
                }
            } else {
                $success = false;
            }
            if ($success) {
                saveMemberToDB();
            }

            if ($success) {
                echo "<h1>Details updated successfully!</h1>";
                echo "<form action='updatemember.php' method='post'>";
                echo "<div class='form-group'>
                    <button style='background-color:green' class='btn btn-primary' type='submit'>View Member Details</button>";
            } else {
                echo "<h1>Oops!</h1>";
                echo "<h3>The following errors were detected:</h3>";
                echo "<p>" . $errorMsg . "</p>";
                echo "<form action='updatemember.php' method='post'>";
                echo "<div class='form-group'>
                    <button style='background-color:red' class='btn btn-primary' type='submit'>View Member Details</button>";
                echo $fname, $lname, $country, $email, $memberid;
            }

            //Helper function that checks input for malicious or unwanted content.
            function sanitize_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }

            /*
             * Helper function to write the member data to the DB
             */
            function saveMemberToDB() {
                global $fname, $lname, $email, $country, $memberid, $pwd_hashed, $errorMsg, $success;
                // Create database connection.
                $config = parse_ini_file('../../private/db-config.ini');
                $conn = new mysqli($config['servername'], $config['username'],
                        $config['password'], $config['dbname']);
                //Check connection
                if ($conn->connect_error) {
                    $errorMsg = "Connection failed: " . $conn->connect_error;
                    $success = false;
                } else {
                    //If pwd is not empty, user is changing their password
                    if(!empty($_POST["pwd"])) {
                        // Prepare the statement:
                        $stmt = $conn->prepare("UPDATE the_lodge_member SET fname=?, lname=?, country=?, pwd=?, emailAddress=? WHERE memberId=?");
                        // Bind & execute the query statement:
                        $stmt->bind_param("sssssi", $fname, $lname, $country, $pwd_hashed, $email, $memberid);
                        if (!$stmt->execute()) {
                            $errorMsg = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                            $success = false;
                        }
                        $stmt->close();
                    } else {
                        // Prepare the statement:
                        $stmt = $conn->prepare("UPDATE the_lodge_member SET fname=?, lname=?, country=?, emailAddress=? WHERE memberId=?");
                        // Bind & execute the query statement:
                        $stmt->bind_param("ssssi", $fname, $lname, $country, $email, $memberid);
                        if (!$stmt->execute()) {
                            $errorMsg = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                            $success = false;
                        }
                        $stmt->close();
                    }
                }
                $conn->close();
            }
            ?>
        </main>
        <?php
        include "footer.inc.php";
        ?>
    </body>
</html>