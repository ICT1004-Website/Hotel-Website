<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>The Lodge | Home</title>
        <link rel="stylesheet" href="css/carousell.css"/>
        <?php
        include "head.inc.php";
        ?>
    </head>
    <body>
        <?php
        include "nav.inc.php";
        ?> 
        <!--Header-->
        <header class="jumbotron jumbotron-fluid text-center" >
            <h1 class="display-4">Welcome to The Lodge</h1>
            <p class="display-8">Providing you the best living experience from the moment you step into our hotel.</p>
        </header>
        <div class="container">
            <div class="book">
                <form action='room available.php' method='post' class="form-inline">
                    <div class = "form-item">
                        <label for = "checkin-date">Check In Date: </label>
                        <input type = "date" id = "checkin">
                    </div>
                    <div class = "form-item">
                        <label for = "checkout-date">Check Out Date: </label>
                        <input type = "date" id = "checkout">
                    </div>
                    <div class = "form-item">
                        <label for = "adult">Guests: </label>
                        <input type = "number" min = "1" value = "1" max="5" id = "guest">
                    </div>
                    <div class = "form-item">
                        <input type = "submit" class = "btn btn-light" value = "Book Now">
                    </div>
                </form>
            </div>
        </div>


        <!--carousell-->
        <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="d-block w-100" src="https://www.marinabaysands.com/content/dam/singapore/marinabaysands/master/main/home/Revamp/new-homepage/rooms/Deluxe-room.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="https://www.marinabaysands.com/content/dam/singapore/marinabaysands/master/main/home/Revamp/new-homepage/rooms/Premier-room.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="https://www.marinabaysands.com/content/dam/singapore/marinabaysands/master/main/home/Revamp/new-homepage/rooms/Club-room.jpg" alt="Third slide">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>


            <!--google map-->
            <h1>Find Us Here</h1>
            <div class="mapouter">
                <style>.mapouter{position:relative;text-align:right;height:300px;width:100%;}.gmap_canvas {overflow:hidden;background:none!important;height:300px;width:100%;}</style>
                <!--<style>iframe {width:100%;height:100%;}</style>-->
                <div class="gmap_canvas">
                    <iframe width=100% height=100% id="gmap_canvas" src="https://maps.google.com/maps?q=sit%20nanyang&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" allowfullscreen=""></iframe>
                    <a href="https://www.whatismyip-address.com/divi-discount/"></a>
                </div>
            </div>
        </div>

        <?php
        include "footer.inc.php";
        ?>

        <script defer src="js/carousell.js"></script>
    </body>
</html>