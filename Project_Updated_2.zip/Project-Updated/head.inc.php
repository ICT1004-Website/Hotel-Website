  <head>
        
        <link rel="stylesheet"href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
              
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" >
        
        <link rel="stylesheet" href="css/main.css">
        
        
        
       
       
       <!--jQuery-->
       <script defer  src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                   
        <!--Bootstrap JS--> 
        <script defer src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
       
        <script defer src="js/main.js"></script>
            
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
         
    </head>