<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang='en'>
    <head>
        <title>The Lodge | Booking Summary</title>
        <?php
        include "head.inc.php"
        ?>
    </head>
    <body class="c">
        <?php
        include "nav.inc.php";
        ?>
        <header class="jumbotron jumbotron-fluid text-center">
            <h1 class="display-4">Booking Summary</h1>
        </header>
        <main class ="container">

            <section class="block">                
                <div class="row">                    
                    <article>    
                        <?php
                        $success = true;
                        if (!empty($_POST['days'])) {
                            $days = sanitize_input($_POST["days"]);
                        }
                        if (!empty($_POST['price'])) {
                            $price = sanitize_input($_POST["price"]);
                        }
                        if (is_null($_SESSION["memberid"])) {
                            $comment = $fname = $lname = $country = $email = $errorMsg = "";

                            if (!empty($_POST['fname'])) {
                                $fname = sanitize_input($_POST["fname"]);
                            }
                            if (!empty($_POST['lname'])) {
                                $lname = sanitize_input($_POST["lname"]);
                            } else {
                                $success = false;
                                $errorMsg .= "Last name is not entered.<br>";
                            }
                            if (!empty($_POST['country'])) {
                                $country = sanitize_input($_POST["country"]);
                            } else {
                                $success = false;
                                $errorMsg .= "Country is not entered.<br>";
                            }
                            if (empty($_POST["email"])) {
                                $errorMsg .= "Email is required.<br>";
                                $success = false;
                            } else {
                                $email = sanitize_input($_POST["email"]);
// Additional check to make sure e-mail address is well-formed.
                                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                    $errorMsg .= "Invalid email format.<br>";
                                    $success = false;
                                }
                            }
                            $memberId = null;
                            
                        }

                        if (isset($_SESSION["memberid"])) {
                            $guestId = null;
                        }
                        if (!empty($_POST['comment'])) {
                            $comment = sanitize_input($_POST["comment"]);
                        }

                        if ($success) {
                            echo "<h2>Booking Successful!</h2>";
                            echo "<h3>Personal Details</h3>";
                            if (is_null($_SESSION["memberid"])) {
                                echo "<p>First Name: $fname</p>";
                                echo "<p>Last Name: $lname</p>";
                                echo "<p>Country: $country</p>";
                                echo "<p>Email Address: $email</p>";
                                saveGuestToDB();
                                // Retrieve newly created guestId //
                                $config = parse_ini_file('../../private/db-config.ini');
                                $conn = new mysqli($config['servername'], $config['username'],
                                        $config['password'], $config['dbname']);
                                //Check connection
                                if ($conn->connect_error) {
                                    $errorMsg = "Connection failed: " . $conn->connect_error;
                                    $success = false;
                                }
                                $sql = "SELECT guestId FROM the_lodge_guest ORDER BY guestId DESC;";
                                $result = $conn->query($sql);
                                $row = $result->fetch_assoc();
                                echo "<p>Guest Id: " . $row['guestId'] . "</p>";
                                $guestId = $row['guestId'];
                                $conn->close();
                                ///////////////////////////////////////
                            }

                            if (isset($_SESSION["memberid"])) {
                                echo "<p>First Name: " . $_SESSION["memfname"] . "</p>";
                                echo "<p>Last Name: " . $_SESSION["memlname"] . "</p>";
                                echo "<p>Country: " . $_SESSION["memcountry"] . "</p>";
                                echo "<p>Email Address: " . $_SESSION["mememail"] . "</p>";
                            }
                            echo "<h3>" . $_SESSION['roomtype'] . "</h3>";
                            echo "<img src='images/" . $_SESSION['image'] . "' alt='" . $_SESSION['roomtype'] . "' style='max-width:40%;height:auto;'/>";

                            // Create database connection.
                            $config = parse_ini_file('../../private/db-config.ini');
                            $conn = new mysqli($config['servername'], $config['username'],
                                    $config['password'], $config['dbname']);
                            //Check connection
                            if ($conn->connect_error) {
                                $errorMsg = "Connection failed: " . $conn->connect_error;
                                $success = false;
                            }
                            // Retrieve Room No //
                            $sql = "SELECT room_no from the_lodge_rooms WHERE roomtypeId in 
                                (SELECT roomtypeId from the_lodge_roomtype WHERE image = '" . $_SESSION['image'] . "' AND room_no not in 
                                (select room_no from the_lodge_booking WHERE '" . $_SESSION['arrival'] . "' >= arrival AND '" . $_SESSION['checkout'] . "' <= checkout));";
                            // Bind & execute the query statement: //
                            $result = $conn->query($sql);
                            $row = $result->fetch_assoc();
                            echo "<p>Room number: " . $row['room_no'] . "</p>";
                            echo "<p>Arrival Date: " . $_SESSION['arrival'] . "</p>";
                            echo "<p>Checkout Date: " . $_SESSION['checkout'] . "</p>";
                            echo "<p>Number of Guests: " . $_SESSION['quantity'] . "</p>";
                            echo "<p>Special Request: " . $comment . "</p>";
                            echo "<p>Total Price: $" . $_SESSION['totalprice'] . "</p>";
                            $room_no = $row['room_no'];
                            $conn->close();
                            ///////////////////////////////////////
                            /// Insert Booking into Database ///
                            $config = parse_ini_file('../../private/db-config.ini');
                            $conn = new mysqli($config['servername'], $config['username'],
                                    $config['password'], $config['dbname']);
                            //Check connection
                            if ($conn->connect_error) {
                                $errorMsg = "Connection failed: " . $conn->connect_error;
                                $success = false;
                            }
                            if (isset($_SESSION["memberid"])) {
                                $sql = "INSERT INTO the_lodge_booking (arrival, checkout, comments, no_of_guests, total_price, room_no, memberId) "
                                        . "VALUES ('" . $_SESSION['arrival'] . "','" . $_SESSION['checkout'] . "','" . $comment . "'," . (int) $_SESSION['quantity'] . "," .
                                        (float) $_SESSION['totalprice'] . "," . (int) $room_no . "," . (int) $_SESSION['memberid'] . ");";
                            }
                            if (is_null($_SESSION["memberid"])) {
                                $sql = "INSERT INTO the_lodge_booking (arrival, checkout, comments, no_of_guests, total_price, room_no, guestId) "
                                        . "VALUES ('" . $_SESSION['arrival'] . "','" . $_SESSION['checkout'] . "','" . $comment . "'," . (int) $_SESSION['quantity'] . "," .
                                        (float) $_SESSION['totalprice'] . "," . (int) $room_no . "," . (int) $guestId . ");";
                            }
                            if ($conn->query($sql) === TRUE) {
                                echo "<p>Booking Details has been saved successfully!</p>";
                            }
                            if (isset($_SESSION["memberid"])) {
                                echo "<form action='viewbooking.php' method='post'>";
                                echo "<div class='form-inline'>
                                        <button class='btn btn-dark' type='submit'>View Booking</button></div><br>";
                                echo "</form>";
                            }

                            $conn->close();
                        } else {
                            echo "<div class='justifycont'>";
                            echo "<h2>Booking is Not Successful!</h2>";
                            echo "<h3>Please see the error details below</h3>";                            
                            echo "<h4>$errorMsg</h4>";
                            echo "<form action='booking.php' method='post'>";
                            echo "<div class='form-inline'>";
                            echo "<input type='hidden' name='start' value='" . $_SESSION['arrival'] . "'></div>";
                            echo "<div class='form-inline'>";
                            echo "<input type='hidden' name='end' value='" . $_SESSION['checkout'] . "'></div>";
                            echo "<div class='form-inline'>";
                            echo "<input type='hidden' name='days' value='" . $_SESSION['days'] . "'></div>";
                            echo "<div class='form-inline'>";
                            echo "<input type='hidden' name='quantity' value='" . $_SESSION['quantity'] . "'></div>";
                            echo "<div class='form-inline'>";
                            echo "<input type='hidden' name='price' value='" . $_SESSION['price'] . "'></div>";
                            echo "<div class='form-inline'>";
                            echo "<input type='hidden' name='image' value='" . $_SESSION['image'] . "'></div>";
                            echo "<div class='form-inline'>";
                            echo "<input type='hidden' name='roomtype' value='" . $_SESSION['roomtype'] . "'></div>";
                            echo "<div class='form-inline'>
                    <button class='btn btn-dark' type='submit'>BACK</button></div><br>";
                            echo "</form>";
                            echo "</div>";
                        }

                        function sanitize_input($data) {
                            $data = trim($data);
                            $data = stripslashes($data);
                            $data = htmlspecialchars($data);
                            return $data;
                        }

                        function saveGuestToDB() {
                            global $fname, $lname, $email, $country, $errorMsg, $success;
// Create database connection.
                            $config = parse_ini_file('../../private/db-config.ini');
                            $conn = new mysqli($config['servername'], $config['username'],
                                    $config['password'], $config['dbname']);
                            //Check connection
                            if ($conn->connect_error) {
                                $errorMsg = "Connection failed: " . $conn->connect_error;
                                $success = false;
                            } else {
// Prepare the statement:
                                // insert into database
                                $stmt = $conn->prepare("INSERT INTO the_lodge_guest (fname, lname, country, emailAddress) VALUES (?, ?, ?, ?)");
// Bind & execute the query statement:
                                $stmt->bind_param("ssss", $fname, $lname, $country, $email);
                                if (!$stmt->execute()) {
                                    $errorMsg = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                                    $success = false;
                                }
                                $stmt->close();
                                // retrieve guessId from database                            
                            }
                            $conn->close();
                        }
                        ?>

                    </article>
                </div>
            </section>
        </main>
        <?php
        include "footer.inc.php";
        ?>
    </body>
</html>