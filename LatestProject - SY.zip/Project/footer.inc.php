
<!-- Footer -->
<footer class="footer-text text-center py-3">

        <h1>Contact</h1>
        The Lodge<br>  
        45 Alexander Road<br>  
        098345<br> 
        +65 6555 6444<br>
        
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">
        
        © 2020 Copyright: The Lodge

    </div>
    <!-- Copyright -->

</footer>