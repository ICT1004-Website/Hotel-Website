<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="en">
    <head>
        <title>The Lodge | Home</title>
        <?php
        include "head.inc.php";
        ?>
    </head>
    <body>
        <main>
            <div class="container-fluid">
                <?php
                include "nav.inc.php";
                ?> 
            </div>
            <header class="jumbotron jumbotron-fluid text-center">
                <h1 class='display-4'>Welcome to The Lodge</h1>
                <h2 class='display-5'>AN EXCEPTIONAL HOTEL</h2>
                <h3 class='display-6'>Providing you the best living experience from the moment you step into our hotel.</h3>
            </header>
            <div class="container">
                <form action='room_available.php' method='post' class="form-inline">
                    <div class="form-item">
                        <label for="start">Check-In Date:</label>
                        <input required type="date" name="start" id="start">  
                    </div>
                    <div class="form-item">
                        <label for="end">Check-Out Date:</label>
                        <input required type="date" name="end" id="end"> 
                    </div>
                    <div class="form-item">
                        <label for="quantity">Guests:</label>
                        <input required type="number" id="quantity" name="quantity" min="1" max="5" >
                    </div>
                    <div class = "form-item">
                        <input type = "submit" class = "btn btn-light" value = "Book Now">
                    </div>
                </form>
            </div>

            <div class="container">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="images/double_room.jpg" alt="First slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="images/single_room.jpg" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="images/villa.jpg" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="images/suites.jpg" alt="Fourth slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="images/studio.jpg" alt="Fifth slide">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>


                <section>
                    <h2>Find Us Here</h2>
                    <div class="mapouter">
                        <map class="gmap_canvas" name="map" aria-labelledby="gmap_canvas">
                            <iframe style="width:100%; height:100%;" id="gmap_canvas" src="https://maps.google.com/maps?q=sit%20nanyang&t=&z=13&ie=UTF8&iwloc=&output=embed" allowfullscreen="" title="map"></iframe>
                        </map>                
                    </div>
                </section>

            </div>
        </main>
        <?php
        include "footer.inc.php";
        ?>

    </body>
</html>