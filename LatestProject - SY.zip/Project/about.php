<!DOCTYPE html>
<html lang='en'>
    <head>
        <title>The Lodge | About Us</title>
        <?php
        include "head.inc.php";
        ?>
        <link  rel="stylesheet" href="css/aboutus.css">
        
    </head>
    <body>
        <main>
            <div class="container-fluid">
        <?php
        include "nav.inc.php";
        ?>
            </div>
        <header class="jumbotron jumbotron-fluid text-center">
            <h1 class="display-4">About Us!</h1>      
        </header>  
        <div class="container">
        <section id="aboutus">
            <div class="about-section">
                <div class="inner-container">
                    <div class="row">
                        <div class="col-sm-7">
                            <h2 class="text-center">Our Story</h2>
                            <h4 class="storytext"> We are a group of 5 friends who have the same common goal to create our own hotel empire upon our university graduation. 
                                Our vision is to provide the best experience for our guests. Comfort is our top priority so our guests would not feel unease when staying with us.
                            </h4>
                        </div>
                    </div>
                </div>    
            </div>

        </section>
        </div>
        <?php
        include "footer.inc.php";
        ?>
        </main>        
    </body>
</html>