
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang='en'>
    <head>
        <title>The Lodge | Home</title>
        <?php
        include "head.inc.php";
        ?>
    </head>
    <body class="just">
        <main>
            <div class='container-fluid'>
                <?php
                include "nav.inc.php";
                ?> 
            </div>
            <header class="jumbotron jumbotron-fluid text-center">
                <h1>Welcome to The Lodge</h1>
                <h2>AN EXCEPTIONAL HOTEL</h2>
                <p>Providing you the best living experience from the moment you step into our hotel.</p>
            </header>
            <div class="container">
                <section>
                    <?php
                    $start = $end = $guest = "";
                    $guest = $_POST['quantity'];
                    $start = date("Y-m-d", strtotime($_POST['start']));
                    $end = date("Y-m-d", strtotime($_POST['end']));
                    $days = strtotime($end) - strtotime($start);
                    $days = round($days / (60 * 60 * 24));
                    $config = parse_ini_file('../../private/db-config.ini');
                    $conn = new mysqli($config['servername'], $config['username'],
                            $config['password'], $config['dbname']);
                    //Check connection
                    if ($conn->connect_error) {
                        $errorMsg = "Connection failed: " . $conn->connect_error;
                        $success = false;
                    }
                    $sql = "select * from the_lodge_roomtype 
                    where roomtypeId in  
                    (SELECT distinct roomtypeId from the_lodge_rooms where room_no not in 
                    (select room_no from the_lodge_booking WHERE '" . $start . "' >= arrival AND '" . $end . "' <= checkout));";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {

                            echo "<h2>" . $row["description"] . "</h2><br>";

                            if ($row["description"] == "single room") {

                                echo "<div class='row'>";
                                echo "<div class='col'>";
                                echo "<img class='d-block w-75 mh-75 displayed' src='images/" . $row["image"] . "' alt='" . $row["image"] .
                                "' ><br>";
                                echo "<div class='col'>";
                                echo "<p class='rate'><span>$" . $row["price_per_night"] . "/</span>Per Night</p><br>";
                                echo "<form action='booking.php' method='post'>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='roomtype' value='" . $row['description'] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='image' value='" . $row["image"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='price' value='" . $row["price_per_night"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='start' value='" . $start . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='end' value='" . $end . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='days' value='" . $days . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='quantity' value='" . $guest . "'></div>";
                                echo "<div class='form-group'>
                    <button class='btn btn-light' type='submit'>Book Room</button></div><br>";
                                echo "</form>";
                                echo "</div>";
                                echo "</div>";
                                echo "</div>";
                            } else if ($row["description"] == "double room") {
                                echo "<div class='row'>";
                                echo "<div class='col'>";
                                echo "<img class='d-block w-75 mh-75 displayed' src='images/" . $row["image"] . "' alt='" . $row["image"] .
                                "' ><br>";
                                echo "<div class='col'>";
                                echo "<p class='rate'><span>$" . $row["price_per_night"] . "/</span>Per Night</p><br>";
                                echo "<form action='booking.php' method='post'>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='roomtype' value='" . $row['description'] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='image' value='" . $row["image"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='price' value='" . $row["price_per_night"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='start' value='" . $start . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='end' value='" . $end . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='days' value='" . $days . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='quantity' value='" . $guest . "'></div>";
                                echo "<div class='form-group'>
                    <button class='btn btn-light' type='submit'>Book Room</button></div><br>";
                                echo "</form>";
                                echo "</div>";
                                echo "</div>";
                                echo "</div>";
                            } else if ($row["description"] == "suites") {
                                echo "<div class='row'>";
                                echo "<div class='col'>";
                                echo "<img class='d-block w-75 mh-75 displayed' src='images/" . $row["image"] . "' alt='" . $row["image"] .
                                "' ><br>";
                                echo "<div class='col'>";
                                echo "<p class='rate'><span>$" . $row["price_per_night"] . "/</span>Per Night</p><br>";
                                echo "<form action='booking.php' method='post'>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='roomtype' value='" . $row['description'] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='image' value='" . $row["image"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='price' value='" . $row["price_per_night"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='start' value='" . $start . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='end' value='" . $end . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='days' value='" . $days . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='quantity' value='" . $guest . "'></div>";
                                echo "<div class='form-group'>
                    <button class='btn btn-light' type='submit'>Book Room</button></div><br>";
                                echo "</form>";
                                echo "</div>";
                                echo "</div>";
                                echo "</div>";
                            } else if ($row["description"] == "studio") {
                                echo "<div class='row'>";
                                echo "<div class='col'>";
                                echo "<img class='d-block w-75 mh-75 displayed' src='images/" . $row["image"] . "' alt='" . $row["image"] .
                                "' ><br>";
                                echo "<div class='col'>";
                                echo "<p class='rate'><span>$" . $row["price_per_night"] . "/</span>Per Night</p><br>";
                                echo "<form action='booking.php' method='post'>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='roomtype' value='" . $row['description'] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='image' value='" . $row["image"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='price' value='" . $row["price_per_night"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='start' value='" . $start . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='end' value='" . $end . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='days' value='" . $days . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='quantity' value='" . $guest . "'></div>";
                                echo "<div class='form-group'>
                    <button class='btn btn-light' type='submit'>Book Room</button></div><br>";
                                echo "</form>";
                                echo "</div>";
                                echo "</div>";
                                echo "</div>";
                            } else if ($row["description"] == "villa") {
                                echo "<div class='row'>";
                                echo "<div class='col'>";
                                echo "<img class='d-block w-75 mh-75 displayed' src='images/" . $row["image"] . "' alt='" . $row["image"] .
                                "' ><br>";
                                echo "<div class='col'>";
                                echo "<p class='rate'><span>$" . $row["price_per_night"] . "/</span>Per Night</p><br>";
                                echo "<form action='booking.php' method='post'>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='roomtype' value='" . $row['description'] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='image' value='" . $row["image"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='price' value='" . $row["price_per_night"] . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='start' value='" . $start . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='end' value='" . $end . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='days' value='" . $days . "'></div>";
                                echo "<div class='form-inline'>";
                                echo "<input type='hidden' name='quantity' value='" . $guest . "'></div>";
                                echo "<div class='form-group'>
                    <button class='btn btn-light' type='submit'>Book Room</button></div><br>";
                                echo "</form>";
                                echo "</div>";
                                echo "</div>";
                                echo "</div>";
                            } else {
                                echo "<p>So sorry, there are no rooms available for the date choosen, Please select another date.</p> <br>";
                            }
                        }
                    } else {
                        echo "Please select the number of guests.";
                    }

                    $conn->close();
                    ?>
                </section>            
            </div>
            <?php
            include "footer.inc.php";
            ?>
        </main>
    </body>
</html>